# Mercy, Moving
A first exploration study of a forgotten American town on an immense walking platform.

From the repository root:

```sh
node projects/mercy-moving/serve.mjs
```

Open http://localhost:4177. Uses the repository's installed Three.js 0.170.0; no new installation is needed. Three.js is served locally. The optional Google Fonts request can fail without preventing play; system fallbacks apply.

WASD to walk, drag to look, double-click for pointer lock, E to observe or open/close the diner, V for third-person, Escape for notes/pause. Touch has movement buttons and drag-look. Walk north past the motel to the ROAD ENDS sign to look down at the platform legs.

Use Field Notes → Bring someone → Host. Copy the entire invitation to another browser's Join input. Four peers maximum; public relay/ICE connectivity varies. Host must remain open. The host simulation continues while the host is in the notes menu so guests can explore. Leave restores solo exploration. There is no persistence yet.

Implemented: authored exterior town; furnished diner interior and shared door; original articulated civilian figures; fog/rain/neon; synthesized rain and platform sound; deck edges and animated legs; collision; first/third-person; optional host-authoritative P2P.

Not implemented: lethal visitors, cave, necklace, protected shelter rules, economy/building, save/load, actual world travel or host migration. Other building interiors are sealed scenery. The original low-poly civilian figures are provisional and need a dedicated character-art pass. Gait uses a fixed walking speed; Shift is not a sprint in this build.

Portable build: `node projects/mercy-moving/package.mjs` produces `artifacts/mercy-moving/mercy-moving.html`, with the generated material atlas and application embedded and Three.js pinned to a CDN.

Verification:
```sh
node --test projects/mercy-moving/session.test.mjs
node projects/mercy-moving/check-browser.mjs
node projects/mercy-moving/check-p2p.mjs
node projects/mercy-moving/check-browser.mjs --portable
```
Browser scripts use the existing /tmp/warehouse-validation Playwright install and system Chrome. Run the server first. Evidence is in artifacts/mercy-moving.

Provenance and process: BUILD-JOURNAL.md, warehouse-parts.json, LICENSES.md. Published to ISW as mercy-moving on baseSepolia; see parts/mercy-moving.parts.receipts.json for the pinned release receipt.
