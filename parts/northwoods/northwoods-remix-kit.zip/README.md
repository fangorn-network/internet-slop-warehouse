# Northwoods CC0 remix kit

Run `node prepare.mjs`, then `python3 -m http.server 8080`. Open http://localhost:8080. No install is needed for the game; Three.js loads from jsDelivr. To rebuild model files, run `npm install --ignore-scripts`, `npm run textures`, `npm run models`. See REFERENCE.md for module contracts, WFC and P2P composition.

Original source, textures and models: CC0-1.0. Snow photo texture: Poly Haven snow_02, CC0-1.0 (https://polyhaven.com/a/snow_02). Three.js is a separate MIT runtime dependency. This is a solo walking demo; networking is not included.
