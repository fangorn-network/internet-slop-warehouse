# Licenses

Original game/rules/adapter/rendering/tower code and generated tower geometry: CC0-1.0. To the extent possible under law, the authors dedicate all copyright and related rights in these original works to the public domain. https://creativecommons.org/publicdomain/zero/1.0/ . No warranty.

Map geometry, roads, tags and names: © OpenStreetMap contributors, ODbL-1.0. https://www.openstreetmap.org/copyright . The raw source snapshot is included at parts/dead-air/rhinelander-osm.json. Keep attribution and comply with ODbL for map/database derivatives. This data is not relicensed CC0.

Poly Haven CC0: brick (https://polyhaven.com/a/red_brick), snow (https://polyhaven.com/a/snow_02), boombox by Thomas Paul Mouilleron (https://polyhaven.com/a/boombox). Original Northwoods trees/textures and wind: CC0.

OpenFreeMap vector input additionally credits OpenFreeMap and © OpenMapTiles; see https://openfreemap.org/quick_start/ . Vector decoder notices: parts/vendor/MAP-VECTOR-LICENSES.txt, BSD-3-Clause and ISC.

Trystero 0.27.0 and bundled dependencies: MIT and third-party notices in parts/vendor/TRYSTERO-LICENSES.txt. Three.js 0.170.0: MIT, copyright 2010-2024 three.js authors, https://github.com/mrdoob/three.js/blob/r170/LICENSE .
