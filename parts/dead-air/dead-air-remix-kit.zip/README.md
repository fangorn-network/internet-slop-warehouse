# Dead Air Atlas source kit

Run `node prepare.mjs` then `python3 -m http.server 8080`. Open http://localhost:8080. The game loads Three.js from jsDelivr; all catalog modules, maps, models and textures are local. No install is needed to play. Rebuilding the tower model: `npm install --ignore-scripts`, `npm run model`.

Open relay-skirmish.html for Relay Commons, the calm exploration/base-building RPG. Read RELAY-COMMONS-QUICKSTART.md for construction and model conventions. Read DEAD-AIR-QUICKSTART.md for controls, complete gameplay, module contracts, coordinate requests, real P2P and limitations. GAME-SYSTEMS.md inventories existing and new reusable systems.

Original source and generated tower: CC0-1.0. **OSM map data is ODbL-1.0, not CC0**. Other models/textures are CC0 with their creators in the manifest. Three.js and Trystero remain MIT. Bundled vector decoders retain BSD-3-Clause/ISC (parts/vendor/MAP-VECTOR-LICENSES.txt). Preserve contributor attribution and notices.
